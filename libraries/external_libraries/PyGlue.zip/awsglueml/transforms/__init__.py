# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Licensed under the Amazon Software License (the "License"). You may not use
# this file except in compliance with the License. A copy of the License is
# located at
#
#  http://aws.amazon.com/asl/
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express
# or implied. See the License for the specific language governing
# permissions and limitations under the License.

from .find_matches import FindMatches
from .find_incremental_matches import FindIncrementalMatches
from .fill_missing_values import FillMissingValues
import json

ALL_TRANSFORMS = {FindMatches, FindIncrementalMatches, FillMissingValues}

__all__ = [transform.__name__ for transform in ALL_TRANSFORMS]

def get_transforms():
    '''
    Get list of available transforms.
    :return: List of available transforms
    '''
    return {transform() for transform in ALL_TRANSFORMS}

def get_transform(name):
    '''
    Get transform.
    :param name: Name of transform to get
    :return: Transform
    '''
    transform, = [t for t in get_transforms() if t.name().lower() == name.lower()] or (None,)
    return transform

def describe_transform(name):
    '''
    Describe transform.
    :param name: Name of transform to describe
    :return: A string describing the transform
    '''
    transform = get_transform(name)
    description = transform.describe() if transform else {}
    return json.dumps(description, sort_keys=True, indent=4, separators=(',', ': '))
